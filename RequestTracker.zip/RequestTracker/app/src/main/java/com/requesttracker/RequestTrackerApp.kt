package com.requesttracker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RequestTrackerApp : Application()
