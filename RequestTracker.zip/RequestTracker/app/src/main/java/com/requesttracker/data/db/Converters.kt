package com.requesttracker.data.db

import androidx.room.TypeConverter
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType

class Converters {
    @TypeConverter fun fromRequestType(value: RequestType): String = value.name
    @TypeConverter fun toRequestType(value: String): RequestType = RequestType.valueOf(value)

    @TypeConverter fun fromRequestStatus(value: RequestStatus): String = value.name
    @TypeConverter fun toRequestStatus(value: String): RequestStatus = RequestStatus.valueOf(value)
}
