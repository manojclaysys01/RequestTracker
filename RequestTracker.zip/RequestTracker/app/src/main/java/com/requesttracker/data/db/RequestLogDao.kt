package com.requesttracker.data.db

import androidx.room.*
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import kotlinx.coroutines.flow.Flow

@Dao
interface RequestLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: RequestLog): Long

    @Delete
    suspend fun delete(log: RequestLog)

    @Query("DELETE FROM request_logs")
    suspend fun deleteAll()

    @Query("DELETE FROM request_logs WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("SELECT * FROM request_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<RequestLog>>

    @Query("""
        SELECT * FROM request_logs 
        WHERE (:type IS NULL OR type = :type)
          AND (:status IS NULL OR status = :status)
          AND (:query IS NULL OR url LIKE '%' || :query || '%' 
               OR requestBody LIKE '%' || :query || '%'
               OR responseBody LIKE '%' || :query || '%')
          AND (:fromTs IS NULL OR timestamp >= :fromTs)
          AND (:toTs IS NULL OR timestamp <= :toTs)
        ORDER BY timestamp DESC
    """)
    fun getFilteredLogs(
        type: String? = null,
        status: String? = null,
        query: String? = null,
        fromTs: Long? = null,
        toTs: Long? = null
    ): Flow<List<RequestLog>>

    @Query("SELECT * FROM request_logs WHERE id = :id")
    suspend fun getById(id: Long): RequestLog?

    @Query("SELECT COUNT(*) FROM request_logs")
    fun getTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM request_logs WHERE status = 'SUCCESS'")
    fun getSuccessCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM request_logs WHERE status = 'ERROR'")
    fun getErrorCount(): Flow<Int>

    @Query("SELECT AVG(durationMs) FROM request_logs WHERE durationMs IS NOT NULL")
    fun getAverageDuration(): Flow<Double?>

    @Query("SELECT * FROM request_logs ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentLogs(limit: Int = 500): List<RequestLog>
}
