package com.requesttracker.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.requesttracker.data.model.RequestLog

@Database(entities = [RequestLog::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class RequestTrackerDatabase : RoomDatabase() {
    abstract fun requestLogDao(): RequestLogDao
}
