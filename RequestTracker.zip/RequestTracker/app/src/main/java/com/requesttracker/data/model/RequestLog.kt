package com.requesttracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class RequestType { HTTP, APP_TO_APP }
enum class RequestStatus { SUCCESS, ERROR, PENDING }

@Entity(tableName = "request_logs")
data class RequestLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: RequestType,
    val method: String,           // GET, POST, PUT, DELETE, etc. or "IPC" for app-to-app
    val url: String,              // URL or Intent action
    val requestHeaders: String,   // JSON string
    val requestBody: String?,     // Request payload
    val responseCode: Int?,       // HTTP status or result code
    val responseHeaders: String?, // JSON string
    val responseBody: String?,    // Response payload
    val status: RequestStatus,
    val durationMs: Long?,        // Round-trip time in milliseconds
    val sourceApp: String?,       // For app-to-app: calling app package
    val targetApp: String?,       // For app-to-app: target app package
    val timestamp: Long = System.currentTimeMillis(),
    val errorMessage: String?     // Error details if status == ERROR
)
