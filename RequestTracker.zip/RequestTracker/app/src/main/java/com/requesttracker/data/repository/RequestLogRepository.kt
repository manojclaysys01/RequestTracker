package com.requesttracker.data.repository

import com.requesttracker.data.db.RequestLogDao
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

data class FilterParams(
    val type: RequestType? = null,
    val status: RequestStatus? = null,
    val query: String? = null,
    val fromTs: Long? = null,
    val toTs: Long? = null
)

@Singleton
class RequestLogRepository @Inject constructor(
    private val dao: RequestLogDao
) {
    val allLogs: Flow<List<RequestLog>> = dao.getAllLogs()
    val totalCount: Flow<Int> = dao.getTotalCount()
    val successCount: Flow<Int> = dao.getSuccessCount()
    val errorCount: Flow<Int> = dao.getErrorCount()
    val avgDuration: Flow<Double?> = dao.getAverageDuration()

    fun getFilteredLogs(params: FilterParams): Flow<List<RequestLog>> =
        dao.getFilteredLogs(
            type = params.type?.name,
            status = params.status?.name,
            query = params.query?.takeIf { it.isNotBlank() },
            fromTs = params.fromTs,
            toTs = params.toTs
        )

    suspend fun insert(log: RequestLog): Long = dao.insert(log)
    suspend fun delete(log: RequestLog) = dao.delete(log)
    suspend fun deleteAll() = dao.deleteAll()
    suspend fun deleteByIds(ids: List<Long>) = dao.deleteByIds(ids)
    suspend fun getById(id: Long): RequestLog? = dao.getById(id)
    suspend fun getRecentLogs(limit: Int = 500): List<RequestLog> = dao.getRecentLogs(limit)
}
