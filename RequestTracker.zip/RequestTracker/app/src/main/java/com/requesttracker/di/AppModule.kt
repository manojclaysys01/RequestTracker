package com.requesttracker.di

import android.content.Context
import androidx.room.Room
import com.requesttracker.data.db.RequestLogDao
import com.requesttracker.data.db.RequestTrackerDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): RequestTrackerDatabase =
        Room.databaseBuilder(context, RequestTrackerDatabase::class.java, "request_tracker.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideDao(db: RequestTrackerDatabase): RequestLogDao = db.requestLogDao()
}
