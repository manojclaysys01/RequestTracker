package com.requesttracker.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.google.gson.Gson
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import com.requesttracker.data.repository.RequestLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tracks app-to-app communication.
 * Use AppToAppTracker.trackSend() and trackReceive() around your IPC calls.
 */
@Singleton
class AppToAppTracker @Inject constructor(
    private val repository: RequestLogRepository
) {
    private val gson = Gson()
    private val scope = CoroutineScope(Dispatchers.IO)

    /** Call before sending an Intent/IPC to another app */
    fun trackSend(
        action: String,
        targetPackage: String?,
        extras: Map<String, Any?> = emptyMap(),
        sourcePackage: String = "com.requesttracker"
    ): Long {
        val startTime = System.currentTimeMillis()
        val log = RequestLog(
            type = RequestType.APP_TO_APP,
            method = "SEND",
            url = action,
            requestHeaders = gson.toJson(mapOf("source" to sourcePackage, "target" to targetPackage)),
            requestBody = gson.toJson(extras),
            status = RequestStatus.PENDING,
            sourceApp = sourcePackage,
            targetApp = targetPackage,
            timestamp = startTime,
            responseCode = null,
            responseHeaders = null,
            responseBody = null,
            durationMs = null,
            errorMessage = null
        )
        var logId = 0L
        scope.launch {
            logId = repository.insert(log)
        }
        return logId // Use this ID to update after response
    }

    /** Call after receiving a response from another app */
    fun trackReceive(
        logId: Long? = null,
        action: String,
        sourcePackage: String?,
        resultCode: Int,
        responseExtras: Map<String, Any?> = emptyMap(),
        durationMs: Long? = null
    ) {
        val log = RequestLog(
            type = RequestType.APP_TO_APP,
            method = "RECEIVE",
            url = action,
            requestHeaders = gson.toJson(mapOf("source" to sourcePackage)),
            requestBody = null,
            responseCode = resultCode,
            responseHeaders = null,
            responseBody = gson.toJson(responseExtras),
            status = if (resultCode == -1) RequestStatus.SUCCESS else RequestStatus.ERROR,
            sourceApp = sourcePackage,
            durationMs = durationMs,
            errorMessage = if (resultCode != -1) "Result code: $resultCode" else null
        )
        scope.launch { repository.insert(log) }
    }

    /** Convenience: track a complete broadcast intent */
    fun trackBroadcast(
        context: Context,
        intent: Intent,
        direction: String = "OUTGOING"
    ) {
        val extras = mutableMapOf<String, Any?>()
        intent.extras?.keySet()?.forEach { key ->
            extras[key] = intent.extras?.get(key)?.toString()
        }
        val log = RequestLog(
            type = RequestType.APP_TO_APP,
            method = "BROADCAST_$direction",
            url = intent.action ?: "unknown",
            requestHeaders = gson.toJson(mapOf("package" to intent.`package`)),
            requestBody = gson.toJson(extras),
            status = RequestStatus.SUCCESS,
            sourceApp = context.packageName,
            targetApp = intent.`package`,
            responseCode = null,
            responseHeaders = null,
            responseBody = null,
            durationMs = null,
            errorMessage = null
        )
        scope.launch { repository.insert(log) }
    }
}
