package com.requesttracker.service

import com.google.gson.Gson
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import com.requesttracker.data.repository.RequestLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Interceptor
import okhttp3.Response
import okio.Buffer
import javax.inject.Inject
import javax.inject.Singleton

/**
 * OkHttp interceptor that logs all HTTP requests and responses.
 * Add this to your OkHttpClient builder:
 *   .addInterceptor(trackingInterceptor)
 */
@Singleton
class RequestTrackingInterceptor @Inject constructor(
    private val repository: RequestLogRepository
) : Interceptor {

    private val gson = Gson()
    private val scope = CoroutineScope(Dispatchers.IO)

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val startTime = System.currentTimeMillis()

        val requestHeaders = request.headers.toMap()
        val requestBody = try {
            val buffer = Buffer()
            request.body?.writeTo(buffer)
            buffer.readUtf8()
        } catch (e: Exception) { null }

        var response: Response? = null
        var errorMsg: String? = null

        try {
            response = chain.proceed(request)
        } catch (e: Exception) {
            errorMsg = e.message
        }

        val duration = System.currentTimeMillis() - startTime

        val responseHeaders = response?.headers?.toMap()
        val responseBodyStr = try {
            val source = response?.body?.source()
            source?.request(Long.MAX_VALUE)
            source?.buffer?.clone()?.readUtf8()
        } catch (e: Exception) { null }

        val log = RequestLog(
            type = RequestType.HTTP,
            method = request.method,
            url = request.url.toString(),
            requestHeaders = gson.toJson(requestHeaders),
            requestBody = requestBody,
            responseCode = response?.code,
            responseHeaders = responseHeaders?.let { gson.toJson(it) },
            responseBody = responseBodyStr,
            status = when {
                errorMsg != null -> RequestStatus.ERROR
                (response?.code ?: 0) >= 400 -> RequestStatus.ERROR
                else -> RequestStatus.SUCCESS
            },
            durationMs = duration,
            errorMessage = errorMsg
        )

        scope.launch { repository.insert(log) }

        return response ?: throw Exception(errorMsg ?: "Unknown network error")
    }
}
