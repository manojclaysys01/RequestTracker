package com.requesttracker.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.requesttracker.databinding.FragmentDashboardBinding
import com.requesttracker.ui.logs.LogsViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LogsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    binding.cardTotalRequests.statValue.text = state.totalCount.toString()
                    binding.cardTotalRequests.statLabel.text = "Total Requests"

                    binding.cardSuccess.statValue.text = state.successCount.toString()
                    binding.cardSuccess.statLabel.text = "Successful"

                    binding.cardErrors.statValue.text = state.errorCount.toString()
                    binding.cardErrors.statLabel.text = "Errors"

                    binding.cardAvgDuration.statValue.text = state.avgDuration?.let { "${it.toLong()}ms" } ?: "—"
                    binding.cardAvgDuration.statLabel.text = "Avg Duration"

                    // Error rate
                    val errorRate = if (state.totalCount > 0)
                        (state.errorCount * 100.0 / state.totalCount).toInt() else 0
                    binding.progressErrorRate.progress = errorRate
                    binding.textErrorRate.text = "Error Rate: $errorRate%"

                    // Recent logs preview
                    val recentAdapter = binding.recyclerRecent.adapter as? com.requesttracker.ui.logs.RequestLogAdapter
                    recentAdapter?.submitList(state.logs.take(5))
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
