package com.requesttracker.ui.detail

import androidx.lifecycle.ViewModel
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.repository.RequestLogRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: RequestLogRepository
) : ViewModel() {
    suspend fun getLog(id: Long): RequestLog? = repository.getById(id)
}
