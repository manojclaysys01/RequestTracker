package com.requesttracker.ui.detail

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import com.requesttracker.databinding.ActivityRequestDetailBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class RequestDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LOG_ID = "extra_log_id"
    }

    private lateinit var binding: ActivityRequestDetailBinding
    private val viewModel: DetailViewModel by viewModels()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Request Detail"

        val logId = intent.getLongExtra(EXTRA_LOG_ID, -1L)
        if (logId == -1L) { finish(); return }

        lifecycleScope.launch {
            val log = viewModel.getLog(logId)
            if (log == null) { finish(); return@launch }

            supportActionBar?.title = "${log.method} ${if (log.type == RequestType.HTTP) "HTTP" else "IPC"}"

            binding.textTimestamp.text = dateFormat.format(Date(log.timestamp))
            binding.textType.text = log.type.name
            binding.textMethod.text = log.method
            binding.textUrl.text = log.url
            binding.textStatus.text = log.status.name
            binding.textResponseCode.text = log.responseCode?.toString() ?: "N/A"
            binding.textDuration.text = log.durationMs?.let { "${it} ms" } ?: "N/A"

            // Source/Target apps (for IPC)
            if (log.type == RequestType.APP_TO_APP) {
                binding.groupApps.visibility = View.VISIBLE
                binding.textSourceApp.text = log.sourceApp ?: "—"
                binding.textTargetApp.text = log.targetApp ?: "—"
            }

            // Error
            if (log.status == RequestStatus.ERROR && log.errorMessage != null) {
                binding.groupError.visibility = View.VISIBLE
                binding.textError.text = log.errorMessage
            }

            // Request section
            binding.textRequestHeaders.text = formatJson(log.requestHeaders)
            binding.textRequestBody.text = log.requestBody?.let { formatJson(it) } ?: "Empty"

            // Response section
            binding.textResponseHeaders.text = log.responseHeaders?.let { formatJson(it) } ?: "N/A"
            binding.textResponseBody.text = log.responseBody?.let { formatJson(it) } ?: "Empty"

            // Copy buttons
            binding.btnCopyRequest.setOnClickListener {
                copyToClipboard("Request", "${log.url}\n\n${log.requestHeaders}\n\n${log.requestBody}")
            }
            binding.btnCopyResponse.setOnClickListener {
                copyToClipboard("Response", "${log.responseHeaders}\n\n${log.responseBody}")
            }
        }
    }

    private fun formatJson(json: String?): String {
        if (json.isNullOrBlank()) return "—"
        return try {
            val gson = com.google.gson.GsonBuilder().setPrettyPrinting().create()
            val element = gson.fromJson(json, Any::class.java)
            gson.toJson(element)
        } catch (e: Exception) {
            json
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Snackbar.make(binding.root, "Copied to clipboard", Snackbar.LENGTH_SHORT).show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { onBackPressedDispatcher.onBackPressed(); return true }
        return super.onOptionsItemSelected(item)
    }
}
