package com.requesttracker.ui.logs

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.requesttracker.R
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import com.requesttracker.databinding.FragmentLogsBinding
import com.requesttracker.ui.detail.RequestDetailActivity
import com.requesttracker.util.ExportUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LogsFragment : Fragment() {

    private var _binding: FragmentLogsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LogsViewModel by viewModels()
    private lateinit var adapter: RequestLogAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLogsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupFilters()
        setupMenu()
        observeState()
    }

    private fun setupRecyclerView() {
        adapter = RequestLogAdapter { log ->
            Intent(requireContext(), RequestDetailActivity::class.java).also {
                it.putExtra(RequestDetailActivity.EXTRA_LOG_ID, log.id)
                startActivity(it)
            }
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener {
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun setupFilters() {
        // Type filter chips
        binding.chipAll.setOnClickListener { viewModel.setTypeFilter(null) }
        binding.chipHttp.setOnClickListener { viewModel.setTypeFilter(RequestType.HTTP) }
        binding.chipAppToApp.setOnClickListener { viewModel.setTypeFilter(RequestType.APP_TO_APP) }

        // Status filter chips
        binding.chipSuccess.setOnClickListener { viewModel.setStatusFilter(RequestStatus.SUCCESS) }
        binding.chipError.setOnClickListener { viewModel.setStatusFilter(RequestStatus.ERROR) }
        binding.chipClearStatus.setOnClickListener { viewModel.setStatusFilter(null) }
    }

    private fun setupMenu() {
        requireActivity().addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, inflater: MenuInflater) {
                inflater.inflate(R.menu.menu_logs, menu)
                val searchItem = menu.findItem(R.id.action_search)
                val searchView = searchItem.actionView as SearchView
                searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(q: String?) = true.also { viewModel.setSearchQuery(q) }
                    override fun onQueryTextChange(q: String?) = true.also { viewModel.setSearchQuery(q) }
                })
            }

            override fun onMenuItemSelected(item: MenuItem): Boolean = when (item.itemId) {
                R.id.action_export_csv -> exportLogs("csv").let { true }
                R.id.action_export_json -> exportLogs("json").let { true }
                R.id.action_clear_all -> showClearConfirmation().let { true }
                R.id.action_filter -> showFilterDialog().let { true }
                else -> false
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    private fun exportLogs(format: String) {
        lifecycleScope.launch {
            val logs = viewModel.getRecentLogs()
            val uri = if (format == "csv") ExportUtil.exportToCsv(requireContext(), logs)
                      else ExportUtil.exportToJson(requireContext(), logs)
            ExportUtil.shareFile(requireContext(), uri, if (format == "csv") "text/csv" else "application/json")
        }
    }

    private fun showClearConfirmation() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Clear All Logs")
            .setMessage("This will permanently delete all tracked requests. Continue?")
            .setPositiveButton("Delete All") { _, _ -> viewModel.deleteAll() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFilterDialog() {
        val statuses = arrayOf("All", "Success", "Error", "Pending")
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Filter by Status")
            .setItems(statuses) { _, which ->
                viewModel.setStatusFilter(when (which) {
                    1 -> RequestStatus.SUCCESS
                    2 -> RequestStatus.ERROR
                    else -> null
                })
            }
            .show()
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    adapter.submitList(state.logs)
                    binding.emptyView.visibility = if (state.logs.isEmpty()) View.VISIBLE else View.GONE
                    binding.recyclerView.visibility = if (state.logs.isEmpty()) View.GONE else View.VISIBLE

                    // Update stats bar
                    binding.textTotal.text = "Total: ${state.totalCount}"
                    binding.textSuccess.text = "✓ ${state.successCount}"
                    binding.textError.text = "✗ ${state.errorCount}"
                    state.avgDuration?.let {
                        binding.textAvgDuration.text = "Avg: ${it.toLong()}ms"
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
