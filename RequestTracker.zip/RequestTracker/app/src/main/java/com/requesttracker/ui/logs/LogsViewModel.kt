package com.requesttracker.ui.logs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import com.requesttracker.data.repository.FilterParams
import com.requesttracker.data.repository.RequestLogRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UiState(
    val logs: List<RequestLog> = emptyList(),
    val isLoading: Boolean = false,
    val totalCount: Int = 0,
    val successCount: Int = 0,
    val errorCount: Int = 0,
    val avgDuration: Double? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class LogsViewModel @Inject constructor(
    private val repository: RequestLogRepository
) : ViewModel() {

    private val _filterParams = MutableStateFlow(FilterParams())
    val filterParams: StateFlow<FilterParams> = _filterParams.asStateFlow()

    val uiState: StateFlow<UiState> = combine(
        _filterParams.flatMapLatest { repository.getFilteredLogs(it) },
        repository.totalCount,
        repository.successCount,
        repository.errorCount,
        repository.avgDuration
    ) { logs, total, success, error, avg ->
        UiState(logs = logs, totalCount = total, successCount = success, errorCount = error, avgDuration = avg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState(isLoading = true))

    fun setTypeFilter(type: RequestType?) {
        _filterParams.update { it.copy(type = type) }
    }

    fun setStatusFilter(status: RequestStatus?) {
        _filterParams.update { it.copy(status = status) }
    }

    fun setSearchQuery(query: String?) {
        _filterParams.update { it.copy(query = query) }
    }

    fun setDateRange(fromTs: Long?, toTs: Long?) {
        _filterParams.update { it.copy(fromTs = fromTs, toTs = toTs) }
    }

    fun clearFilters() {
        _filterParams.value = FilterParams()
    }

    fun deleteLog(log: RequestLog) = viewModelScope.launch {
        repository.delete(log)
    }

    fun deleteAll() = viewModelScope.launch {
        repository.deleteAll()
    }

    suspend fun getRecentLogs(limit: Int = 500) = repository.getRecentLogs(limit)
}
