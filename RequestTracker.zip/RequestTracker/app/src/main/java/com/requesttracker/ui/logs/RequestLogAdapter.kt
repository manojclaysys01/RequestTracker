package com.requesttracker.ui.logs

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.requesttracker.data.model.RequestLog
import com.requesttracker.data.model.RequestStatus
import com.requesttracker.data.model.RequestType
import com.requesttracker.databinding.ItemRequestLogBinding
import java.text.SimpleDateFormat
import java.util.*

class RequestLogAdapter(
    private val onClick: (RequestLog) -> Unit
) : ListAdapter<RequestLog, RequestLogAdapter.ViewHolder>(DIFF_CALLBACK) {

    private val dateFormat = SimpleDateFormat("MM/dd HH:mm:ss", Locale.US)

    inner class ViewHolder(private val binding: ItemRequestLogBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(log: RequestLog) {
            binding.textMethod.text = log.method
            binding.textUrl.text = log.url
            binding.textTimestamp.text = dateFormat.format(Date(log.timestamp))
            binding.textDuration.text = log.durationMs?.let { "${it}ms" } ?: "—"
            binding.textResponseCode.text = log.responseCode?.toString() ?: "—"
            binding.textType.text = if (log.type == RequestType.HTTP) "HTTP" else "IPC"

            // Status color coding
            val color = when (log.status) {
                RequestStatus.SUCCESS -> Color.parseColor("#4CAF50")
                RequestStatus.ERROR -> Color.parseColor("#F44336")
                RequestStatus.PENDING -> Color.parseColor("#FF9800")
            }
            binding.statusIndicator.setBackgroundColor(color)
            binding.textStatus.text = log.status.name
            binding.textStatus.setTextColor(color)

            binding.root.setOnClickListener { onClick(log) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRequestLogBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<RequestLog>() {
            override fun areItemsTheSame(old: RequestLog, new: RequestLog) = old.id == new.id
            override fun areContentsTheSame(old: RequestLog, new: RequestLog) = old == new
        }
    }
}
