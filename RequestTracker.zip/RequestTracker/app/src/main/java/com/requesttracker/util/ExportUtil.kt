package com.requesttracker.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.requesttracker.data.model.RequestLog
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

object ExportUtil {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    fun exportToJson(context: Context, logs: List<RequestLog>): Uri {
        val file = File(context.cacheDir, "request_logs_${System.currentTimeMillis()}.json")
        val json = gson.toJson(logs.map { log ->
            mapOf(
                "id" to log.id,
                "type" to log.type.name,
                "method" to log.method,
                "url" to log.url,
                "requestHeaders" to log.requestHeaders,
                "requestBody" to log.requestBody,
                "responseCode" to log.responseCode,
                "responseHeaders" to log.responseHeaders,
                "responseBody" to log.responseBody,
                "status" to log.status.name,
                "durationMs" to log.durationMs,
                "sourceApp" to log.sourceApp,
                "targetApp" to log.targetApp,
                "timestamp" to dateFormat.format(Date(log.timestamp)),
                "errorMessage" to log.errorMessage
            )
        })
        file.writeText(json)
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun exportToCsv(context: Context, logs: List<RequestLog>): Uri {
        val file = File(context.cacheDir, "request_logs_${System.currentTimeMillis()}.csv")
        FileWriter(file).use { writer ->
            // Header
            writer.appendLine("ID,Timestamp,Type,Method,URL,Status,ResponseCode,DurationMs,SourceApp,TargetApp,ErrorMessage")
            // Rows
            logs.forEach { log ->
                writer.appendLine(
                    listOf(
                        log.id,
                        dateFormat.format(Date(log.timestamp)),
                        log.type.name,
                        log.method,
                        log.url.escapeForCsv(),
                        log.status.name,
                        log.responseCode ?: "",
                        log.durationMs ?: "",
                        log.sourceApp ?: "",
                        log.targetApp ?: "",
                        log.errorMessage?.escapeForCsv() ?: ""
                    ).joinToString(",")
                )
            }
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun shareFile(context: Context, uri: Uri, mimeType: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export Request Logs"))
    }

    private fun String.escapeForCsv(): String {
        return if (contains(",") || contains("\"") || contains("\n")) {
            "\"${replace("\"", "\"\"")}\""
        } else this
    }
}
